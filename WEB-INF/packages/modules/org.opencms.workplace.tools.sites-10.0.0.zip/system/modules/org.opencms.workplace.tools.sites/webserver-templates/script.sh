#!/bin/bash

# simple script reloading the apache web server
/etc/init.d/apache2 reload
